# Attribution

| Skill(s) | Upstream | Licence |
|---|---|---|
| karpathy-llm-wiki | https://github.com/Astro-Han/karpathy-llm-wiki | see LICENSE-karpathy-llm-wiki |
| prd, transcript-ingest, spec-gap-issues (informed by `prd`, `meeting-minutes`, `create-github-issues-for-unmet-specification-requirements`) | https://github.com/github/awesome-copilot | see LICENSE-awesome-copilot |
| docs/agents/issue-tracker.md | https://github.com/mattpocock/skills (setup templates) | MIT |
| transcript-ingest, standup-digest, brd, stories | written for this package | MIT |
