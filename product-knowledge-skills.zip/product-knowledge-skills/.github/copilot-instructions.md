# Copilot instructions: product knowledge skills

This repository keeps an LLM-maintained product knowledge base under `knowledge/` and a set of Agent Skills under `.github/skills/` that read from and write to it. Load a skill's full `SKILL.md` before applying it; the table below is only routing.

## The knowledge base

- `knowledge/raw/` — immutable sources: meeting transcripts (`raw/meetings/`), interview answers (`raw/interviews/`), documents, emails, exported tickets. Never edited after creation.
- `knowledge/wiki/` — compiled articles the agent owns: `features/`, `decisions/`, `requirements/register.md`, `risks/register.md`, `questions/open.md`, `actions/log.md`, `people/`, `digests/`, `glossary.md`, plus `index.md` (global index) and `log.md` (append-only operation log).
- Grounding rule: every number, date, quote and name in `wiki/` exists verbatim in a raw file linked from that article. `karpathy-llm-wiki` lint checks it.
- Requirement ids are stable and traceable: `REQ-` (wiki register) → `BR-` (BRD) → `FR-`/`NFR-` (PRD) → `ST-` (stories) → issue numbers. Never renumber.
- `docs/requirements/{brd,prd,stories}/` holds the generated documents. They cite the wiki; the wiki cites raw.

## Which skill to use when

| Situation | Skill |
|---|---|
| A transcript, meeting notes, or call summary arrives | `transcript-ingest` |
| Any other source to remember (doc, email, ticket export, article); a question about what we know; lint | `karpathy-llm-wiki` |
| End of week / sprint: what shipped, what is blocked, what keeps coming up | `standup-digest` |
| A new initiative needs business justification and scope | `brd` |
| A feature needs product requirements, user stories, acceptance criteria | `prd` |
| PRD approved; backlog needs INVEST stories with Gherkin | `stories` |
| Are the issues and the code in line with the PRD? Create the missing issues | `spec-gap-issues` |

Each skill is independent: one input, one output, shared state only through `knowledge/` and `docs/requirements/`. Run them alone or chain them in any order.

## Suggested chain (not enforced)

transcript-ingest (per meeting) → standup-digest (weekly) → brd (once per initiative) → prd (per feature) → stories → spec-gap-issues, or `to-tickets` from the SDLC skills package if installed, for tracer-bullet engineering tickets.

If the SDLC skills package is installed in this repo: glossary terms found by `transcript-ingest` should also be proposed for `CONTEXT.md`; decisions that meet the ADR bar should be proposed for `docs/adr/`; `grill-with-docs` is the right tool when a PRD interview turns into a design discussion.

## Working rules

- Facts come from sources; when the sources are silent, write `[TBD — who should answer]`, never a plausible guess.
- Newer dated source wins a conflict; keep the old claim with a Status block rather than deleting it.
- Attribute only what the transcript attributes; unlabeled speakers stay unlabeled.
- Nothing personal about people beyond role, ownership and stated interests.
- One mention is a question, not a requirement. Requirements need a confirming statement.
- Documents are drafts for human review: show the draft, ask for feedback on the sections that matter most, do not commit.
- Keep all knowledge in plain markdown in this repo so it is reviewable by PR and usable by any agent.
