---
name: stories
description: "Turn a PRD (or a feature article in the wiki) into a set of feature stories ready for a backlog: INVEST-sized, Gherkin acceptance criteria, traced to FR/NFR ids, with estimates in T-shirt sizes and dependencies. Writes docs/requirements/stories/<slug>.md and optionally publishes each story as a GitHub issue. Use when the user says 'write the stories', 'break the PRD into stories', 'user stories for', or 'backlog for this feature'."
---

# Stories

Feature stories are the bridge between the PRD and engineering tickets. They are user-facing and vertically complete (a story delivers observable behaviour), not layer tasks.

## Inputs

- `docs/requirements/prd/<slug>.md` (preferred) or `knowledge/wiki/features/<feature>.md`.
- Existing stories file `docs/requirements/stories/<slug>.md` (update in place, keep ids).
- `docs/agents/issue-tracker.md` when publishing.

## Rules

- **INVEST**: independent, negotiable, valuable, estimable, small (one to a few days), testable. Split anything larger by user outcome, not by layer.
- Every story traces to at least one FR/NFR id; every Must FR is covered by at least one story. Report uncovered requirements rather than inventing stories.
- Acceptance criteria in Gherkin (`Given / When / Then`), each scenario independently checkable. Include at least one negative or edge scenario per story where the PRD implies one.
- Non-functional requirements become either acceptance criteria on the stories they constrain, or a dedicated enabler story when they need their own work (for example, "audit logging for exports").
- Use the glossary's vocabulary (`knowledge/wiki/glossary.md`, and `CONTEXT.md` if present).
- No file paths, no implementation steps, no code. Implementation planning is `writing-plans` / `to-tickets` (SDLC package).

## Output

`docs/requirements/stories/<slug>.md`:

```markdown
# Stories: <Feature name>

> PRD: docs/requirements/prd/<slug>.md v<version>   Updated: YYYY-MM-DD

## Coverage
Table: FR/NFR id → story ids. List uncovered ids explicitly.

## Stories

### ST-<slug>-01 — <short title>
**As a** <persona> **I want** <capability> **so that** <benefit>.
**Traces to:** FR-<slug>-02, NFR-<slug>-01
**Priority:** Must   **Size:** S / M / L   **Depends on:** ST-<slug>-00 or none
**Acceptance criteria**
```gherkin
Scenario: <name>
  Given ...
  When ...
  Then ...
```
**Notes:** anything the PRD says that the implementer must not miss; open questions that block this story.
```

## Process

1. Read the PRD fully; list FR/NFR ids.
2. Draft stories; build the coverage table; split or merge until every story is INVEST and every Must requirement is covered.
3. Order by dependency then priority.
4. Show the user the story titles with size and dependencies first (one line each); iterate on granularity before writing acceptance criteria in full.
5. Write the file. Log `## [YYYY-MM-DD] stories | <slug>` in `knowledge/wiki/log.md`.
6. If asked to publish: one GitHub issue per story via `docs/agents/issue-tracker.md`, title `ST-<slug>-nn: <title>`, body = the story block, label `story`, blocking links per Depends on. Record the issue numbers back in the stories file. Do not create duplicates: search existing issues for the story id first.

Next step: `to-tickets` (SDLC package) if engineering wants thinner tracer-bullet slices than the stories, or `spec-gap-issues` to reconcile with an existing backlog.
