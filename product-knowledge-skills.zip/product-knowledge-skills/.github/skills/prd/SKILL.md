---
name: prd
description: "Write or update a Product Requirements Document (PRD) for a feature or product, grounded in the knowledge base and the BRD: problem, users and personas, user stories with acceptance criteria, functional and non-functional requirements with stable ids, non-goals, dependencies, rollout, risks, open questions. Every requirement cites a wiki article or raw source. Use when the user says 'write the PRD', 'product requirements', 'document the feature', 'spec this feature out', or after a BRD exists."
---

# PRD

The PRD is the single source of truth for *what the product does* for a feature. It is the input to `stories` (feature stories), `to-tickets` (SDLC package) and `spec-gap-issues`. It is not a technical design: architecture belongs in ADRs and `to-spec`.

## Inputs

1. Feature or product name (ask if missing).
2. The BRD at `docs/requirements/brd/<slug>.md` if one exists (business objectives and BR ids are referenced, not restated).
3. The knowledge base: `knowledge/wiki/features/<feature>.md`, `requirements/register.md`, `decisions/`, `risks/register.md`, `questions/open.md`, `glossary.md`, `people/`; raw files where the wiki is thin.
4. An existing PRD at `docs/requirements/prd/<slug>.md` (update in place, bump version, keep a Changelog section).
5. The codebase, if this repo contains it: existing behaviour is a constraint and a source of prior art.

If the wiki has no requirements for the feature, run a short interview (numbered `❓ Qn` / `➡️` format, max six questions per round), save the answers to `knowledge/raw/interviews/YYYY-MM-DD-prd-<slug>.md`, compile them into the wiki, then write.

## Requirement quality

Concrete and testable. "Fast", "intuitive", "robust" are not requirements.

```diff
- Search should be fast and relevant.
+ Search returns first results within 300 ms (p95) for the 50k-record catalogue.
+ Top-10 results contain the exact-title match when one exists.
```

Ids are stable: functional `FR-<slug>-nn`, non-functional `NFR-<slug>-nn`. Reuse the wiki register's `REQ-` ids in a "Traces to" column so a requirement can be followed from transcript → wiki → PRD → story → ticket. Never renumber; mark removed requirements `Withdrawn` with the date and reason.

## Output

`docs/requirements/prd/<slug>.md`:

```markdown
# PRD: <Feature name>

> Status: Draft | In review | Approved   Version: 0.1   Owner: <role/name>   Updated: YYYY-MM-DD
> BRD: docs/requirements/brd/<slug>.md   Business objectives served: BO-1, BO-3

## 1. Summary
Problem (2 sentences), proposed solution (2 sentences), success criteria (3–5 measurable, tied to BRD metrics).

## 2. Users and personas
Who, their goal, their context. Only personas evidenced in sources.

## 3. User stories
`US-nn — As a <persona>, I want <capability>, so that <benefit>.`
Each with acceptance criteria in Given / When / Then, and a Priority (Must / Should / Could).

## 4. Functional requirements
Table: id, requirement, priority, traces to (REQ / BR ids), source.

## 5. Non-functional requirements
Performance, security and privacy, accessibility, compliance, observability, data retention. Same table shape.

## 6. Non-goals
Explicit. Include things discussed and rejected, with the decision link.

## 7. User flow
Numbered happy path plus the main error and edge paths. Text or a Mermaid diagram.

## 8. Dependencies and integration points
Systems, teams, data, third parties. From sources only.

## 9. Rollout
Phases (MVP → next), feature flags, migration or backfill needs, success checkpoints.

## 10. Risks
From the wiki risk register plus anything specific to this feature.

## 11. Open questions
Each with who should answer and by when if stated.

## 12. Changelog
Version, date, what changed, why (link to the meeting or decision).
```

## Process

1. Gather facts with sources before writing. Where the BRD and the wiki disagree, the newer dated source wins; flag the conflict in Open questions.
2. Draft. Grounding rule applies to every number, date, quote and name.
3. Self-check: every FR/NFR has a source and a priority; every Must requirement is covered by at least one user story's acceptance criteria; non-goals non-empty; no "TBD" without an owner.
4. Record in `knowledge/wiki/index.md` ("Requirements documents") and `wiki/log.md`: `## [YYYY-MM-DD] prd | <slug> v<version>`. Compile any newly surfaced decisions into `wiki/decisions/`.
5. Present the draft; ask for feedback on user stories and non-goals first. Do not commit.

Next steps: `stories` to expand into feature stories, or `to-tickets` (SDLC package) to slice straight into tracer-bullet issues; `spec-gap-issues` to reconcile with existing issues.
