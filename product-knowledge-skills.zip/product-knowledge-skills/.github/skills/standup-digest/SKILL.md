---
name: standup-digest
description: "Roll up a period of standups (a week, a sprint, or 'since the last digest') from the knowledge base into one digest: what shipped, what is blocked and for how long, commitments that slipped, topics that keep recurring, and drift between what the team is doing and what the requirements say. Use when the user says 'standup digest', 'weekly digest', 'what happened this week', 'what's blocked', or 'summarise the standups'."
---

# Standup Digest

Reads standups already ingested by `transcript-ingest` (raw files under `knowledge/raw/meetings/` of type standup, and the Status sections and `wiki/actions/log.md` they updated) and writes one digest article. It does not ingest transcripts itself; if standups for the period are missing from `knowledge/raw/meetings/`, say which dates and offer to ingest them first.

## Period

Default: since the last digest (see `wiki/digests/`), else the last 7 days. The user can give any range or a sprint name.

## Process

1. **Collect.** List the standup raw files in the period. Read each, plus the wiki articles they touched (from `wiki/log.md` entries of the period) and `wiki/actions/log.md`.
2. **Extract per person, per day**: done / doing / blocked, as stated. Keep names as they appear in the transcripts.
3. **Compute across days:**
   - **Blocked items** with first-seen date and days blocked; who is blocking whom.
   - **Slipped commitments**: "will do X by Y" statements whose Y passed without a matching done.
   - **Recurring topics**: anything mentioned in 3+ standups; recurrence usually means an undocumented decision or a missing requirement.
   - **Drift**: work reported that maps to no requirement in `wiki/requirements/register.md`, and requirements marked in progress with no standup mention in the period.
   - **Completed**: what was reported done, mapped to REQ ids where possible.
4. **Write** `knowledge/wiki/digests/YYYY-MM-DD-standup-digest.md` (archive-style page: Sources = the standup raw files; Updated = today). Under 400 words. Sections: Completed, Blocked (table: item, owner, blocked since, days, blocker), Slipped, Recurring topics, Drift, Suggested actions.
5. **Update** `wiki/index.md` (Digests section) and append to `wiki/log.md`: `## [YYYY-MM-DD] digest | standups <from>..<to>`.
6. **Report** the digest in the conversation. Offer, where applicable: open an issue per blocker older than 3 days (via `docs/agents/issue-tracker.md`); add recurring topics to `wiki/questions/open.md`; run `prd` if drift shows work outside any requirement.

## Rules

- Only what the standups say. No inferred sentiment, no performance judgements about people.
- Every quoted phrase must exist in a raw file (grounding rule from the wiki skill).
- Digests are point-in-time; never edit an old digest, write a new one.
