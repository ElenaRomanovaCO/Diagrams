---
name: spec-gap-issues
description: "Reconcile a PRD or stories file with the GitHub issue tracker and, if the repo contains the code, with the implementation: find requirements and stories that have no issue and no implementation, find issues that map to no requirement (scope creep or undocumented work), and create only the missing issues after confirmation. Use when the user says 'what's missing from the backlog', 'create issues for unmet requirements', 'sync the PRD with issues', or 'are we building what the spec says'."
---

# Spec Gap Issues

Keeps three things aligned: the requirements (PRD / stories), the backlog (issues), and the code.

## Inputs

- `docs/requirements/prd/<slug>.md` and/or `docs/requirements/stories/<slug>.md` (ask which feature if not given).
- Issues, via `docs/agents/issue-tracker.md` (GitHub through `gh` by default): `gh issue list --state all --search "<slug> OR FR-<slug> OR ST-<slug>" --json number,title,body,labels,state`.
- The codebase, when present: search for the feature's glossary terms, routes, components and tests.

## Process

1. **Extract** the requirement set: every FR/NFR id (PRD) and ST id (stories) with its priority.
2. **Map to issues.** For each id, find issues whose title or body mentions it, or whose title clearly matches the requirement text. Record: covered (open or closed issue), uncovered.
3. **Map to code** (if the repo has it). For each id, look for evidence of implementation: tests naming the behaviour, routes, components, feature flags. Record: implemented, partial, absent, unknown. Evidence must be concrete (file and symbol); no guessing.
4. **Reverse map.** For open issues that carry the feature's label or slug but match no requirement id, list them as "unmapped work" for the user to decide: add a requirement to the PRD, or close/relabel the issue.
5. **Report** a table before creating anything:

   | id | requirement (short) | priority | issue | code | proposed action |
   |---|---|---|---|---|---|

   Proposed actions: create issue; link existing issue; mark implemented in PRD; needs decision.
6. **Create issues** only for rows the user approves. One issue per uncovered requirement or story, in dependency order, using the repo's `feature_request` issue template when one exists (`.github/ISSUE_TEMPLATE/`), otherwise this body:

   ```markdown
   ## Requirement
   <id> — <requirement text verbatim from the PRD/stories>
   Source: docs/requirements/prd/<slug>.md (v<version>)

   ## Acceptance criteria
   <copied from the story or PRD>

   ## Blocked by
   <issue refs or "None">
   ```

   Labels: `feature`, plus `ready-for-agent` when the user says the ticket is safe to hand to an agent. Write the created issue numbers back into the PRD/stories file next to the ids.
7. **Log** `## [YYYY-MM-DD] spec-gap | <slug>: <n> created, <n> linked, <n> unmapped` in `knowledge/wiki/log.md`.

## Rules

- Never create an issue for a requirement that already has one; when unsure, link and ask.
- Never close or edit existing issues in this skill; only report.
- Unknown implementation status is reported as unknown, not as absent.
