---
name: transcript-ingest
description: "Ingest a meeting transcript (standup, brainstorm, discovery call, design review, planning, retro, stakeholder interview) into the knowledge base: save it immutably under knowledge/raw/meetings/, extract every decision, requirement, risk, open question, action item and glossary term with speaker and date, and merge them into the right wiki articles with citations. Use when the user pastes or points to a transcript, meeting notes, a call recording summary, or says 'ingest this meeting', 'process the standup', 'what came out of the call'."
---

# Transcript Ingest

Turns a meeting transcript into grounded, reusable knowledge. Builds on the `karpathy-llm-wiki` skill: same `knowledge/raw/` and `knowledge/wiki/` layout, same article, index and log formats, same grounding rule (every quote, number, date and name in the wiki exists verbatim in the raw file). Read that skill's `references/` when you need exact formats.

Do not produce a "meeting summary" and stop. The summary is a by-product; the product is the updated wiki.

## Inputs

A transcript in any form: pasted text, a `.txt`/`.md`/`.vtt`/`.docx` file path, or exported notes from a meeting tool. If speakers are unlabeled, keep it that way; never invent attribution. If the date is missing, ask once; if unknown, use the file date and mark `Published: Unknown`.

Optional user hints: meeting type, project or feature name, attendees.

## Process

### 1. Save the raw file

`knowledge/raw/meetings/YYYY-MM-DD-<meeting-type>-<slug>.md` using the raw template. Header fields: Source (tool or "pasted transcript"), Collected (today), Published (meeting date), Meeting type, Attendees (only as stated in the transcript), Project. Preserve the transcript text; clean timestamps and filler only if the user asks. Raw files are never edited afterwards.

### 2. Extract insights

Read the whole transcript once, then extract into these buckets. Each item carries `(speaker, YYYY-MM-DD)` and a short verbatim anchor quote (3–15 words) that exists in the raw file, so the grounding check can find it.

| Bucket | What qualifies | Where it goes |
|---|---|---|
| **Decision** | Something the group agreed to do or not do, or a choice between options | `wiki/decisions/<topic>.md` and the feature article it affects |
| **Requirement** | A stated need, constraint, rule, or expectation of the product ("it must", "users need", "we can't ship without") | The feature or capability article under `wiki/features/`; the requirements register `wiki/requirements/register.md` |
| **Risk / concern** | A worry, dependency, unknown, or thing that could go wrong | `wiki/risks/register.md` and the affected feature article |
| **Open question** | Something raised and not resolved | `wiki/questions/open.md` (with who should answer it, if stated) |
| **Action item** | A commitment by a named person, with a due date if stated | `wiki/actions/log.md`; optionally a GitHub issue via `docs/agents/issue-tracker.md` if the user asks |
| **Glossary term** | A domain word used with a specific meaning, or two words used for one thing | `wiki/glossary.md`; also flag it for the repo's `CONTEXT.md` if the SDLC package is installed |
| **Stakeholder fact** | Who owns what, who decides, who cares about which outcome | `wiki/people/<name>.md` (role and interests only, nothing personal) |
| **Status / progress** | What was done, what is blocked (standups) | The feature article's Status section; feeds `standup-digest` |

Rules:

- Requirements are written as the speaker meant them, in the glossary's vocabulary, one per line, each with a stable id `REQ-<feature>-<nn>` assigned in the register (continue numbering; never renumber).
- A decision that reverses an earlier one: keep the old one with a **Status: Outdated** block, per the wiki skill. Never silently rewrite history.
- A requirement that contradicts an existing one: mark both **Status: Disputed** and add it to open questions.
- Do not upgrade one mention into a rule. "Maybe we need SSO" is an open question, not a requirement, unless someone confirms it.
- Ignore small talk, scheduling chatter, and anything not about the product or the work.

### 3. Triage and compile

Follow the wiki skill's triage (New / Update / Disputed / No material) per bucket. Search `knowledge/wiki/` for the feature names, people and terms before writing, so you merge into existing articles rather than creating parallel ones. Create the topic directories (`features/`, `decisions/`, `requirements/`, `risks/`, `questions/`, `actions/`, `people/`) lazily, only when first needed.

Feature article shape (when creating one):

```markdown
# <Feature name>

> Sources: <speaker/org, date; ...>
> Raw: [<meeting>](../../raw/meetings/<file>.md); ...
> Updated: YYYY-MM-DD

## Overview
## Requirements   (REQ ids with one-line text; details live in the register)
## Decisions      (links into decisions/)
## Risks and open questions
## Status         (latest first, dated)
## See Also
```

### 4. Cascade, index, log

Cascade-update every article materially affected (the wiki skill's rule). Update `wiki/index.md`. Append to `wiki/log.md`:

```
## [YYYY-MM-DD] ingest | meeting: <type> <date> — <slug>
- Disposition: <New; Update; Disputed>
- Raw: raw/meetings/<file>.md
- Extracted: <n> decisions, <n> requirements, <n> risks, <n> questions, <n> actions, <n> terms
- Updated: <article>, <article>
```

### 5. Report to the user

A compact digest, under 250 words: decisions, new requirements (with ids), risks, open questions with suggested owners, action items. Then: "Wiki updated: <list of articles>". Offer next steps only when they apply: `brd` or `prd` if a feature now has enough requirements; `standup-digest` if this was a standup; `to-tickets` (SDLC package) if actions are engineering work.

## Batch mode

Given a folder of transcripts, process them one at a time in chronological order (shared state: index, log, cascades). Print one line per file when done.
