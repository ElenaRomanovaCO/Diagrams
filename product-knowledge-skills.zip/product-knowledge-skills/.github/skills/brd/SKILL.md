---
name: brd
description: "Write or update a Business Requirements Document (BRD) for a product, initiative or feature, grounded in the knowledge base: business objectives, problem statement, stakeholders, scope and out-of-scope, high-level business requirements, assumptions, constraints, success metrics, risks. Every claim cites a wiki article or raw source. Use when the user says 'write the BRD', 'business requirements', 'business case for', or before a PRD exists for a new initiative."
---

# BRD

A BRD answers *why* and *what for the business*; the PRD answers *what the product does*. Keep them separate: no user stories, screens or APIs here.

## Inputs

1. The initiative or feature name (ask if missing).
2. The knowledge base: search `knowledge/wiki/` (index, `features/`, `decisions/`, `requirements/register.md`, `risks/register.md`, `questions/open.md`, `people/`) and, where the wiki is thin, the raw files under `knowledge/raw/`.
3. Any existing BRD at `docs/requirements/brd/<slug>.md` (update it; do not fork).

If the wiki has fewer than three sources on the topic, say so, list what is missing (objectives? stakeholders? metrics?) and offer a short interview using the numbered-question format (`❓ Qn` / `➡️ recommended answer`), maximum six questions per round. Interview answers are new knowledge: save them to `knowledge/raw/interviews/YYYY-MM-DD-brd-<slug>.md` and compile into the wiki before writing the BRD, so the BRD still cites sources.

## Output

`docs/requirements/brd/<slug>.md`, following this structure. Every section ends with a `Sources:` line of markdown links to wiki articles (project-root-relative). Unknowns are written as `[TBD — <who should answer>]`, never guessed.

```markdown
# BRD: <Initiative name>

> Status: Draft | In review | Approved   Version: 0.1   Owner: <role or name>   Updated: YYYY-MM-DD
> Related: PRD (docs/requirements/prd/<slug>.md) if it exists

## 1. Executive summary
Three to five sentences: the business problem, the proposed initiative, the expected outcome.

## 2. Business objectives
Numbered BO-1, BO-2 ... Each objective is measurable or tied to a metric in section 8.

## 3. Problem statement and background
Current state, pain, cost of doing nothing. Cite the meetings or documents where this was stated.

## 4. Stakeholders
Table: role, name (if stated), interest, decision authority (decides / consulted / informed).

## 5. Scope
### In scope
### Out of scope (explicit, with the reason given when it was decided)

## 6. Business requirements
Table: id (BR-nn), requirement, priority (Must / Should / Could), source, related REQ ids from the wiki register.
Requirements are business-level ("customers can complete onboarding without a call"), not solution-level.

## 7. Assumptions and constraints
Assumptions (things believed true, unverified) and constraints (budget, regulatory, timeline, platform) as stated.

## 8. Success metrics
Table: metric, baseline (if known), target, how measured, when reviewed.

## 9. Risks and dependencies
From the wiki risk register plus anything raised in sources; each with likelihood, impact, owner if stated.

## 10. Open questions
From `wiki/questions/open.md` filtered to this initiative; each with who should answer.

## 11. Approval
Names/roles that must sign off, as stated in sources. [TBD] otherwise.
```

## Process

1. Gather (wiki first, raw second). Build a list of candidate facts with their sources before writing anything.
2. Draft the document. Grounding rule applies: numbers, dates, quotes and names must exist in the raw files linked from the cited articles. If a figure is derived, show its components.
3. Self-check: every BR has a source; every BO has a metric; out-of-scope is non-empty or explicitly "none decided yet"; no solution language leaked in (screens, endpoints, tables).
4. Record: add the BRD to `knowledge/wiki/index.md` under a "Requirements documents" section and log `## [YYYY-MM-DD] brd | <slug> v<version>` in `wiki/log.md`. If the BRD contains decisions not yet in `wiki/decisions/`, that is a sign the interview produced new knowledge: compile it.
5. Present the draft and ask for feedback on specific sections (scope and metrics first). Do not commit.

Natural next step: the `prd` skill.
