# Install prompt for the Copilot agent in VS Code

Copy everything below the line, open **Copilot Chat → Agent mode** in VS Code with the target repository open, and paste it. Replace `<PATH>` with where the `product-knowledge-skills` folder is on disk. The target repo can be the product's code repo (then requirements sit next to the code) or a dedicated `product-knowledge` repo; both work.

---

You are installing a product-knowledge skills package into this repository. The package lives at `<PATH>/product-knowledge-skills`. Do the following in order and show me a short summary after each numbered step before moving on. Do not commit or push anything.

1. **Inspect the package.** List `<PATH>/product-knowledge-skills/.github/skills/`: there should be seven skill folders — `karpathy-llm-wiki`, `transcript-ingest`, `standup-digest`, `brd`, `prd`, `stories`, `spec-gap-issues` — each with a `SKILL.md` carrying `name` and `description` front matter. Also confirm `.github/copilot-instructions.md`, `docs/agents/issue-tracker.md`, `knowledge/raw/`, `knowledge/wiki/` and `ATTRIBUTION/` exist in the package.

2. **Check what this repo already has.** Report whether the repo contains: `.github/skills/`, `.github/copilot-instructions.md`, `knowledge/`, `docs/requirements/`, `docs/agents/`, a `CONTEXT.md`, and whether the SDLC skills package is already installed (look for `.github/skills/to-tickets/`). Do not modify anything yet.

3. **Copy the skills.** Copy every folder from the package's `.github/skills/` into this repo's `.github/skills/`, preserving `references/` and `scripts/`. If a folder with the same name already exists, stop and ask me whether to replace it.

4. **Merge the instructions.** If this repo has no `.github/copilot-instructions.md`, copy the package's file. If it has one (for example from the SDLC package), append the package's content under a new heading `## Product knowledge skills` without removing anything, and show me the diff.

5. **Create the knowledge base.** Create `knowledge/raw/` and `knowledge/wiki/` with a `.gitkeep` each, `knowledge/wiki/index.md` containing the heading `# Knowledge Base Index`, and `knowledge/wiki/log.md` containing `# Wiki Log`. Create `docs/requirements/brd/`, `docs/requirements/prd/`, `docs/requirements/stories/` with `.gitkeep`. Copy `docs/agents/issue-tracker.md` into `docs/agents/` only if it does not already exist there. Copy `ATTRIBUTION/` to `docs/agents/ATTRIBUTION-product-knowledge/`.

6. **Check tooling.** Confirm Python 3 is available (`python3 --version`) for the wiki lint script, and that `gh` is installed and authenticated (`gh auth status`) if the remote is GitHub. If the remote is not GitHub, ask me where issues live and update `docs/agents/issue-tracker.md` in prose.

7. **Labels.** If this is a GitHub repo and I confirm, create the labels `story` and `feature` (and `ready-for-agent` if missing). Show the `gh label create` commands and wait for my go-ahead.

8. **Verify the skills are discoverable.** Reload skills if needed. Without doing any real work, tell me which skill you would pick for each of these, quoting its `description`: (a) "here's the transcript from this morning's standup" (b) "what do we know about the export feature?" (c) "what's blocked this week?" (d) "write the business case for self-serve onboarding" (e) "turn the onboarding PRD into stories" (f) "are the issues in sync with the PRD?" (g) "ingest this vendor PDF into the wiki".

9. **Dry run on a sample.** Create a short fictional standup transcript (four speakers, one decision, two requirements, one blocker, one action item, one ambiguous term) at `knowledge/raw/_sample/sample-standup.md`, run `transcript-ingest` on it, then show me the resulting wiki articles and the log entry, then run `karpathy-llm-wiki` lint and show its output. Finally delete `knowledge/raw/_sample/` and the wiki articles created from it, and remove their index and log entries, so the wiki starts empty. Report what the dry run proved and anything that did not work.

10. **First real ingest.** Ask me for the path or paste of a real transcript. If I provide one, run `transcript-ingest` on it and show the digest. If I do not, skip.

11. **Next steps.** In three lines, tell me which feature in the wiki (if any) already has enough material for a `brd` or `prd`, and whether I should install the SDLC skills package for `to-tickets` and `grill-with-docs` if it is not already here.

Print a final checklist of files you created or changed.
