# Product Knowledge Skills

Seven Agent Skills for GitHub Copilot that turn meetings and documents into a grounded knowledge base, and the knowledge base into BRDs, PRDs, feature stories and tickets. Plain markdown in the repo; every claim traceable to its source.

```
product-knowledge-skills/
├── COPILOT-INSTALL-PROMPT.md        ← paste into Copilot Chat (Agent mode)
├── .github/
│   ├── copilot-instructions.md      ← routing table, knowledge-base layout, working rules
│   └── skills/
│       ├── karpathy-llm-wiki/       store: ingest any source, query, lint (raw/ + wiki/)
│       ├── transcript-ingest/       meeting transcript → raw + decisions/requirements/risks/questions/actions/glossary
│       ├── standup-digest/          period of standups → blocked / slipped / recurring / drift digest
│       ├── brd/                     wiki → Business Requirements Document
│       ├── prd/                     wiki + BRD → Product Requirements Document (FR/NFR ids, stories, AC)
│       ├── stories/                 PRD → INVEST stories with Gherkin, optional GitHub issues
│       └── spec-gap-issues/         PRD/stories vs issues vs code → create only the missing issues
├── docs/agents/issue-tracker.md     ← how skills read/publish issues (GitHub via gh)
├── knowledge/raw/  knowledge/wiki/  ← empty knowledge base skeleton
└── ATTRIBUTION/
```

## How it fits together

```
transcripts, docs, emails
        │  transcript-ingest / karpathy-llm-wiki
        ▼
knowledge/raw/  (immutable)  ──cites──▶  knowledge/wiki/  (features, decisions, requirements, risks, questions, actions, people, glossary)
                                               │
              standup-digest ◀─────────────────┤
                                               │  brd → prd → stories
                                               ▼
                                   docs/requirements/{brd,prd,stories}/
                                               │  spec-gap-issues  |  to-tickets (SDLC package)
                                               ▼
                                          GitHub issues
```

Ids chain end to end: `REQ-` (wiki register) → `BR-` (BRD) → `FR-`/`NFR-` (PRD) → `ST-` (stories) → issue numbers.

The skills are independent. Each has one input and one output and shares state only through `knowledge/` and `docs/requirements/`, so you can run any one alone or chain them in any order. The chain above is the suggested one, written into `copilot-instructions.md` as guidance, not enforced.

## Install

1. Put this folder on the machine with the repo.
2. Open the repo in VS Code → Copilot Chat → Agent mode.
3. Paste `COPILOT-INSTALL-PROMPT.md` with `<PATH>` filled in. It copies the skills, merges instructions, creates the knowledge skeleton, checks `python3` and `gh`, runs a discoverability test and a dry-run ingest on a fictional standup (then cleans it up), and offers to ingest your first real transcript.

Works in the product's code repo (requirements next to code, `spec-gap-issues` can check implementation) or in a separate knowledge repo (then `spec-gap-issues` only reconciles with issues).

## Using it day to day

- After a meeting: paste the transcript, say "ingest this". Read the digest; answer any open questions it raised.
- Friday: "standup digest for this week".
- New initiative: "write the BRD for <name>" — it interviews you only where the wiki is silent, and saves the answers as sources.
- Feature ready: "write the PRD for <feature>" → review → "stories for <feature>" → "sync issues with the PRD".
- Any time: "what do we know about <X>?", "lint the wiki".

## Pairing with the SDLC skills package

If both packages are installed in one repo: glossary terms from transcripts are proposed for `CONTEXT.md`; decisions that meet the ADR bar go to `docs/adr/`; `to-tickets` slices a PRD or stories into tracer-bullet engineering tickets; `grill-with-docs` takes over when a PRD interview becomes a design discussion.

## Sources

- Astro-Han/karpathy-llm-wiki (karpathy-llm-wiki, used as-is with the root moved to `knowledge/`)
- github/awesome-copilot (`prd`, `meeting-minutes`, `create-github-issues-for-unmet-specification-requirements` informed the prd, transcript-ingest and spec-gap-issues skills)
- transcript-ingest, standup-digest, brd, stories are new; prd and spec-gap-issues are rewrites grounded in the wiki
