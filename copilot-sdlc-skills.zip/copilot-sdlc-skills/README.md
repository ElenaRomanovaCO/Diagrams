# Copilot SDLC Skills (wave 1 + 1.5)

Seventeen Agent Skills, adapted for GitHub Copilot, that cover the software lifecycle from understanding an existing codebase through scoping, planning, verification and review. They work for new projects and existing ones, for small tasks and big features.

## What's inside

```
copilot-sdlc-skills/
├── COPILOT-INSTALL-PROMPT.md      ← paste into Copilot Chat (Agent mode) to install
├── .github/
│   ├── copilot-instructions.md    ← routing table: which skill when, default flows, working rules
│   └── skills/
│       ├── acquire-codebase-knowledge/   map an existing repo into docs/codebase/
│       ├── ai-ready/                     generate AGENTS.md, instructions, CI, templates
│       ├── zoom-out/                     context brief before touching unfamiliar code
│       ├── grill-me/                     scoping interview (small tasks)
│       ├── grill-with-docs/              scoping interview + CONTEXT.md glossary + ADRs (big features)
│       ├── to-spec/                      conversation → spec issue
│       ├── to-tickets/                   spec → tracer-bullet GitHub issues with blockers
│       ├── writing-plans/                ticket → bite-sized implementation plan
│       ├── verification-before-completion/  evidence before "done"
│       ├── code-review/                  two-axis review: standards + spec
│       ├── retro/                        end-of-task lessons → docs/agents/LESSONS.md
│       ├── dream/                        weekly consolidation of lessons into instructions/ADRs
│       ├── react-best-practices/         Vercel's React/Next.js performance rules (40+)
│       ├── composition-patterns/         React component architecture patterns
│       ├── web-design-guidelines/        100+ a11y/UX/layout rules (vendored)
│       ├── web-design-reviewer/          visual inspection of a running page
│       └── webapp-testing/               Playwright-based browser verification
├── docs/agents/
│   ├── issue-tracker.md           ← how skills read/publish issues (GitHub via gh)
│   └── domain.md                  ← how skills consume CONTEXT.md and ADRs
└── ATTRIBUTION/                   ← upstream licences
```

## Install

1. Put this folder on the machine that has the repo (anywhere; inside the repo is fine, it will be copied from there).
2. Open the repo in VS Code, open Copilot Chat in **Agent** mode.
3. Paste the contents of `COPILOT-INSTALL-PROMPT.md`, replacing `<PATH>`.
4. Answer the agent's questions as it goes (replace existing files?, labels?, `[ASK USER]` items).

Manual alternative: copy `.github/` and `docs/` into the repo root, then ask Copilot "onboard me to this repo".

Skills are discovered automatically from `.github/skills/*/SKILL.md` by Copilot in VS Code, the Copilot CLI, and the Copilot coding agent. If a skill does not trigger, reference it by name ("use the grill-me skill on this").

## Default flows

- **Small task, existing code:** zoom-out → grill-me (one round) → implement → verification-before-completion → code-review
- **Feature, existing code:** zoom-out → grill-with-docs → to-spec → to-tickets → per ticket: writing-plans → implement → verification → code-review
- **New project:** grill-with-docs → to-spec → to-tickets → ai-ready → per ticket as above

## What was changed from upstream

- Claude Code / Codex specific front matter (`disable-model-invocation`, `agents/openai.yaml`) removed; descriptions rewritten as strong trigger phrases so Copilot auto-loads the right skill.
- Slash-command references (`/setup-matt-pocock-skills`, `/tdd`, `superpowers:*`) replaced by plain "use the X skill" phrasing or by the docs in `docs/agents/`.
- `grill-me` and `grill-with-docs` inline the upstream `grilling` and `domain-modeling` skills instead of chaining through a Skill tool.
- `code-review` runs its two axes as sub-agents when available, sequential passes otherwise.
- `writing-plans` saves to `docs/plans/` and hands off to inline execution or the Copilot coding agent instead of superpowers' executors.
- `to-spec` / `to-tickets` publish through `docs/agents/issue-tracker.md` and tag tickets `ready-for-agent`.
- `zoom-out` is new (the upstream one was retired); a scope-guard ("smallest change / not building / defer") was added to both grill skills.
- `ai-ready` is the full John Papa skill rather than the awesome-copilot wrapper.
- `web-design-guidelines` reads a vendored `GUIDELINES.md` instead of fetching from GitHub at run time (works on locked-down networks).
- Vercel skill names dropped the `vercel-` prefix so folder and `name` match.

## Memory loop (retro + dream)

Copilot has no hooks, so the loop is explicit: `retro` runs after `code-review` (the instructions tell the agent to offer it) and appends to `docs/agents/LESSONS.md`; `dream` runs weekly (manually, or as a recurring issue assigned to the Copilot coding agent) and promotes recurring lessons into `copilot-instructions.md`, `CODING_STANDARDS.md`, `CONTEXT.md` or ADRs, then prunes the log. Modelled on Claude's dreaming feature.

## Karpathy guidelines

The four karpathy-guidelines rules (think before coding, simplicity first, surgical changes, goal-driven execution) are merged into `.github/copilot-instructions.md` as always-on working rules rather than shipped as a skill, so they apply to every turn.

## Wave 2 candidates

tdd, systematic-debugging / diagnosing-bugs, implement, triage, improve-codebase-architecture, codebase-design, handoff, setup-pre-commit, autoresearch (metric-driven optimisation loop), anti-ui-slop (needs the UIZZE service), and a custom backend conventions skill for AWS/Amplify.

## Sources

- mattpocock/skills (grill-me, grill-with-docs, to-spec, to-tickets, code-review, docs/agents templates)
- obra/superpowers (writing-plans, verification-before-completion)
- github/awesome-copilot (acquire-codebase-knowledge)
- johnpapa/ai-ready (ai-ready)
- vercel-labs/agent-skills (react-best-practices, composition-patterns, web-design-guidelines) + vercel-labs/web-interface-guidelines (vendored rules)
- github/awesome-copilot (web-design-reviewer, webapp-testing)
- multica-ai/andrej-karpathy-skills (karpathy-guidelines, merged into instructions)
- retro and dream are new, modelled on mattpocock/skills `retro` and Claude Code's dreaming
