# Attribution

| Skill(s) | Upstream | Licence |
|---|---|---|
| grill-me, grill-with-docs, to-spec, to-tickets, code-review, docs/agents templates, retro (basis) | https://github.com/mattpocock/skills | see LICENSE-mattpocock-skills |
| writing-plans, verification-before-completion | https://github.com/obra/superpowers | see LICENSE-superpowers |
| acquire-codebase-knowledge, web-design-reviewer, webapp-testing | https://github.com/github/awesome-copilot | see LICENSE-awesome-copilot |
| ai-ready | https://github.com/johnpapa/ai-ready | see LICENSE-ai-ready |
| react-best-practices, composition-patterns, web-design-guidelines | https://github.com/vercel-labs/agent-skills and https://github.com/vercel-labs/web-interface-guidelines | MIT (declared in each SKILL.md) |
| Working rules in copilot-instructions.md | https://github.com/multica-ai/andrej-karpathy-skills (karpathy-guidelines) | MIT (declared in SKILL.md) |
| zoom-out, dream | written for this package | MIT |
