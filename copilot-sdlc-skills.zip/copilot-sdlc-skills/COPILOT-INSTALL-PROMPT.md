# Install prompt for the Copilot agent in VS Code

Copy everything below the line, open **Copilot Chat → Agent mode** in VS Code with the target repository open, and paste it. The `copilot-sdlc-skills` folder must be somewhere on disk (inside the repo, next to it, or in Downloads); replace `<PATH>` with its location.

---

You are installing an SDLC skills package into this repository. The package lives at `<PATH>/copilot-sdlc-skills`. Do the following in order, and show me a short summary after each numbered step before moving to the next. Do not commit or push anything.

1. **Inspect the package.** List `<PATH>/copilot-sdlc-skills/.github/skills/` (there should be seventeen skill folders: `acquire-codebase-knowledge`, `ai-ready`, `zoom-out`, `grill-me`, `grill-with-docs`, `to-spec`, `to-tickets`, `writing-plans`, `verification-before-completion`, `code-review`, `retro`, `dream`, `react-best-practices`, `composition-patterns`, `web-design-guidelines`, `web-design-reviewer`, `webapp-testing`) and confirm each has a `SKILL.md` with `name` and `description` front matter. Also list `.github/copilot-instructions.md`, `docs/agents/issue-tracker.md`, `docs/agents/domain.md` and the `ATTRIBUTION/` folder in the package.

2. **Check what this repo already has.** Report whether the repo already contains any of: `.github/skills/`, `.github/copilot-instructions.md`, `AGENTS.md`, `CLAUDE.md`, `CONTEXT.md`, `docs/adr/`, `docs/agents/`, `docs/codebase/`, `docs/plans/`, `CONTRIBUTING.md`, `CODING_STANDARDS.md`. Do not modify anything yet.

3. **Copy the skills.** Copy every folder from the package's `.github/skills/` into this repo's `.github/skills/`, preserving subfolders (`assets/`, `references/`, `scripts/`, format files). If a skill folder with the same name already exists here, stop and ask me whether to replace it.

4. **Merge the instructions.** If this repo has no `.github/copilot-instructions.md`, copy the package's file as-is. If it already has one, append the package's content under a new heading `## SDLC skills` without removing anything that is already there, then show me the diff. The package's "Working rules" section (Karpathy guidelines) must end up in the file either way.

5. **Install the agent docs.** Copy `docs/agents/issue-tracker.md` and `docs/agents/domain.md` into this repo's `docs/agents/` (create the folder). Copy `ATTRIBUTION/` to `docs/agents/ATTRIBUTION/` (these are the upstream licences for the skills). Create empty `docs/adr/` and `docs/plans/` folders with a `.gitkeep` each if they do not exist.

6. **Adjust the issue tracker doc to this repo.** Run `git remote -v`. If the remote is GitHub, leave `docs/agents/issue-tracker.md` as is and check that the `gh` CLI is installed and authenticated (`gh auth status`); if it is not, tell me the exact command to fix it. If the remote is not GitHub (Azure DevOps, GitLab, none), ask me where issues live and rewrite `docs/agents/issue-tracker.md` accordingly in prose.

7. **Create the labels** the skills use, if this is a GitHub repo and I confirm: `spec`, `ready-for-agent`, `needs-info`. Show me the `gh label create` commands and wait for my go-ahead before running them.

8. **Verify the skills are discoverable.** Reload skills if your environment needs it. Then, without doing any real work, tell me which skill you would pick for each of these five requests and why, quoting the skill's `description` line: (a) "I need to add a CSV export to the reports page", (b) "review the changes on my branch since main", (c) "onboard me to this repo", (d) "this modal component has twelve boolean props, clean it up", (e) "you keep putting server calls in components, stop doing that".

9. **Run the onboarding.** Use the `acquire-codebase-knowledge` skill on this repo now and produce `docs/codebase/`. At the end list every `[ASK USER]` item it raised so I can answer them.

10. **Seed the memory loop.** Create `docs/agents/LESSONS.md` with the header from the `retro` skill and no entries. If this is a GitHub repo and I confirm, create an issue titled "Weekly dream: consolidate agent lessons" labelled `ready-for-agent` whose body says "Run the dream skill on docs/agents/LESSONS.md and open a PR with the consolidation." Do not assign it yet; I will decide whether to give it to the Copilot coding agent.

11. **Frontend check.** If this repo contains React or Next.js code, check whether Playwright is available (`npx playwright --version`) and whether a Playwright MCP server is configured in VS Code; report what `webapp-testing` and `web-design-reviewer` would need to run, without installing anything.

12. **Propose next steps.** Suggest, in three lines, whether this repo would benefit from running `ai-ready`, and which area of the codebase you would start a `grill-with-docs` session on first to seed `CONTEXT.md` and the first ADRs.

Print a final checklist of files you created or changed.
