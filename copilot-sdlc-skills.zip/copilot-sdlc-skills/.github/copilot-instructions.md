# Copilot instructions: SDLC skills

This repository uses Agent Skills under `.github/skills/`. Each skill is a folder with a `SKILL.md`. Load a skill's full `SKILL.md` before applying it; the descriptions below are only the routing table.

## Which skill to use when

| Situation | Skill |
|---|---|
| First time in this repo, or the user asks to map / document / onboard into the codebase | `acquire-codebase-knowledge` (writes `docs/codebase/`) |
| Make the repo agent-friendly: generate `AGENTS.md`, instructions, CI, issue templates | `ai-ready` |
| About to touch code you have not worked in this session; blast radius unclear | `zoom-out` |
| User wants to scope, stress-test, or think through a change, small or large | `grill-me` |
| Big feature, new subsystem, or the decision deserves a glossary entry / ADR | `grill-with-docs` |
| Conversation has settled; user wants it written up as a spec issue | `to-spec` |
| Approved spec or plan needs to become GitHub issues | `to-tickets` |
| Spec / ticket in hand, about to implement a multi-step change | `writing-plans` (writes `docs/plans/`) |
| About to say "done", "fixed", "passing"; before commit / push / PR | `verification-before-completion` |
| User asks to review a branch, PR, or the changes since a point | `code-review` |
| End of a ticket / PR, or the user corrects you in a reusable way | `retro` (appends to `docs/agents/LESSONS.md`) |
| Weekly, or LESSONS.md is long; consolidate what the agent has learned | `dream` |
| Writing or reviewing React / Next.js code | `react-best-practices` |
| Component API design, boolean-prop sprawl, compound components | `composition-patterns` |
| Reviewing UI code for accessibility, responsiveness, UX | `web-design-guidelines` |
| Visually inspecting a running page for layout / design problems | `web-design-reviewer` |
| Verifying frontend behaviour in a real browser (Playwright) | `webapp-testing` |

## Default flow

- **Small task in existing code:** `zoom-out` → (optional `grill-me`, one round) → implement → `verification-before-completion` → `code-review` → `retro`.
- **Feature in existing code:** `zoom-out` → `grill-with-docs` → `to-spec` → `to-tickets` → per ticket: `writing-plans` → implement → `verification-before-completion` → `code-review` → `retro`.
- **New project:** `grill-with-docs` → `to-spec` → `to-tickets` → `ai-ready` once the skeleton exists → per ticket as above.
- **Reviewing someone else's PR:** `code-review` with the PR number.

For frontend work, `react-best-practices` and `composition-patterns` apply while implementing; `web-design-guidelines` and `webapp-testing` run as part of verification.

Skip steps when the user says to; never skip `verification-before-completion`.

## Project documentation the skills rely on

- `CONTEXT.md` at the root is the domain glossary. Use its vocabulary in code, issues, tests and messages. Do not add implementation details to it.
- `docs/adr/` holds Architecture Decision Records. Read the ones touching the area you work in; if your change contradicts one, say so explicitly instead of silently overriding.
- `docs/codebase/` (if present) is the generated map of the repo: stack, structure, architecture, conventions, integrations, testing, concerns.
- `docs/agents/issue-tracker.md` defines how to read and publish issues (GitHub via `gh` by default).
- `docs/agents/domain.md` defines how to consume the glossary and ADRs.
- `docs/plans/` holds implementation plans.
- `docs/agents/LESSONS.md` is the running log of lessons (written by `retro`, consolidated by `dream`). Read it at the start of non-trivial work.

If any of these files are missing, proceed silently; the skills create them lazily when there is something to write.

## Working rules

Derived from Andrej Karpathy's observations on LLM coding pitfalls (karpathy-guidelines, MIT). They bias toward caution over speed; for trivial tasks use judgement.

**Think before coding.** State assumptions explicitly; if uncertain, ask. If multiple interpretations exist, present them rather than picking silently. If a simpler approach exists, say so and push back. If something is unclear, stop and name what is confusing.

**Simplicity first.** Minimum code that solves the problem, nothing speculative: no features beyond what was asked, no abstractions for single-use code, no configurability that was not requested, no error handling for impossible scenarios. If 200 lines could be 50, rewrite. Ask: would a senior engineer call this overcomplicated?

**Surgical changes.** Every changed line traces to the request. Do not improve adjacent code, comments or formatting; do not refactor what is not broken; match existing style even if you would do it differently. Remove imports/variables your change made unused; mention pre-existing dead code but do not delete it unless asked.

**Goal-driven execution.** Turn tasks into verifiable goals: "add validation" → "write tests for invalid inputs, then make them pass"; "fix the bug" → "write a test that reproduces it, then make it pass"; "refactor X" → "tests pass before and after". For multi-step work state a short plan with verification checkpoints.

Repo-specific rules:

- Say what you are deliberately not building for this ticket.
- Facts come from the repo (search, read, run); decisions come from the user. Never ask the user for something you can look up.
- Follow this repo's conventions over general best practice; call out the conflict if the two disagree.
- Do not claim success without fresh evidence (build / test / lint output in this session).
- Keep issue and PR text free of specific file paths and code snippets unless they encode a decision; they go stale.
- When the user corrects you in a way that will apply again, record it with the `retro` skill.
