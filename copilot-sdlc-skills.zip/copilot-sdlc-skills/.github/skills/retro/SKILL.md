---
name: retro
description: "Retrospective at the end of a task, ticket, or PR: capture what the user corrected, which assumptions were wrong, which repo conventions or gotchas were discovered, and what slowed the agent down. Appends dated lessons to docs/agents/LESSONS.md so future sessions do not repeat the same mistakes. Use when the user says 'retro', 'what did we learn', 'remember this', 'don't do that again', or right after code-review before the work is merged."
---

# Retro

Turn one session's friction into durable lessons. This is the write side of the memory loop; the `dream` skill is the consolidation side.

## When to run

- After `code-review` on a ticket or PR, before it merges.
- Whenever the user corrects you in a way that would apply again ("we never call the DB from components", "always use the shared `apiClient`").
- When the user says "remember this" or "don't do that again".

## Process

### 1. Gather signal from this session

Look back through the conversation and the diff for:

- **Corrections**: anything the user changed, rejected, or re-asked for. Quote the correction, then state the rule it implies.
- **Wrong assumptions**: places where you assumed and were wrong (a file location, a convention, an API shape, how tests run).
- **Discovered conventions and gotchas**: undocumented rules of this repo, environment quirks, commands that only work a certain way, flaky tests, required env vars.
- **Friction**: what took disproportionate time (finding a file, understanding a module, a tool that was noisy or slow), and what would have made it fast (a navigation pointer, a doc, an automated check).
- **Automatable checks**: mistakes that a linter, type rule, test, or CI check could have caught.

Ignore one-off facts that will not recur (a branch name, today's ticket number).

### 2. Classify each lesson by where it belongs

| Kind of lesson | Home |
|---|---|
| Vocabulary / domain meaning | `CONTEXT.md` (via the grill-with-docs skill) |
| Hard-to-reverse design decision | ADR under `docs/adr/` |
| Coding standard the reviewer should enforce | `CODING_STANDARDS.md` (create if missing) |
| Always-on behavioural rule for the agent | `.github/copilot-instructions.md` (only after it has recurred; see `dream`) |
| Something a tool could enforce | an issue titled "Add check: ..." (via `docs/agents/issue-tracker.md`) |
| Everything else, and every lesson on first sighting | `docs/agents/LESSONS.md` |

On first sighting, every lesson goes to `LESSONS.md`. Promotion to the other homes happens in `dream`, except when the user explicitly asks to record a decision now.

### 3. Append to LESSONS.md

Create `docs/agents/LESSONS.md` if missing, with this header:

```markdown
# Lessons learned

Append-only log written by the `retro` skill; consolidated by the `dream` skill. Newest at the bottom.
Format: `- YYYY-MM-DD [category] lesson — evidence (what happened)`
Categories: correction, assumption, convention, gotcha, friction, check.
```

Append one line per lesson, compact, using the repo's vocabulary:

```markdown
- 2026-09-02 [convention] Server actions live in `app/**/actions.ts`, never in components — user moved `exportCsv` out of `ReportsPage`.
- 2026-09-02 [gotcha] `npm test` needs `DATABASE_URL` set or the Prisma tests hang silently — lost ~10 min.
- 2026-09-02 [check] No lint rule stops DB imports in client components — candidate for an eslint restricted-imports rule.
```

### 4. Report

Show the user the lines you appended and ask whether any should be promoted immediately (a decision worth an ADR, a rule for `copilot-instructions.md`, an issue for an automated check). Do the promotions they approve; leave the rest for `dream`.

If `LESSONS.md` is over about 80 lines, suggest running the `dream` skill.
