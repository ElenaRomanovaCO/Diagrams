---
name: grill-with-docs
description: "Interview the user relentlessly about a plan or feature (like grill-me) while building the project's domain model as you go: sharpening terminology, writing the CONTEXT.md glossary, and recording Architecture Decision Records (ADRs). Use for big features, new subsystems, onboarding an existing project into documented decisions, or whenever the user says 'grill with docs', 'let's document decisions', 'write ADRs', or 'build the glossary'. Also use when editing CONTEXT.md or an ADR directly."
---

# Grill With Docs

Two disciplines run at once in this skill:

1. **Grilling**: a relentless, round-based interview until every branch of the design tree is resolved.
2. **Domain modeling**: actively sharpening the project's vocabulary and decisions, writing `CONTEXT.md` and ADRs the moment they crystallise.

Run both together. Grilling supplies the questions; domain modeling captures what the answers reveal.

---

## Part 1: Grilling

Interview the user relentlessly until you reach a shared understanding. Map this as a **design tree**: every decision branches into the decisions that hang off it.

Work the tree in **rounds**. The **frontier** is every decision whose prerequisites are already settled. Ask the whole frontier in one round: number each question and give your recommended answer. Then wait for the user's answers before the next round.

```
❓ **Q1** - **<question title>**: <question body, may include multiple choices>

➡️ <your recommended answer>

---

❓ **Q2** - **<question title>**: <question body>

➡️ <your recommended answer>
```

Each round reshapes the tree: settled decisions push the frontier outward. A question whose answer depends on another question still open in this round belongs to a _later_ round.

Finding _facts_ is your job, never the user's. If a question needs a fact from the codebase, config, git history or docs, look it up with your tools before asking. The _decisions_ are the user's.

Always include the scope-guard questions: smallest change that satisfies the need; what we are deliberately not building; what can be deferred cheaply.

The interview is done when the frontier is empty. Do not act on the design until the user confirms shared understanding.

---

## Part 2: Domain modeling

### File structure

Most repos have a single context:

```
/
├── CONTEXT.md
├── docs/
│   └── adr/
│       ├── 0001-event-sourced-orders.md
│       └── 0002-postgres-for-write-model.md
└── src/
```

If a `CONTEXT-MAP.md` exists at the root, the repo has multiple contexts and it points to where each `CONTEXT.md` and `docs/adr/` lives (see `docs/agents/domain.md`).

Create files lazily: only when you have something to write. If no `CONTEXT.md` exists, create one when the first term is resolved. If no `docs/adr/` exists, create it when the first ADR is needed.

### During the session

**Challenge against the glossary.** When the user uses a term that conflicts with the existing language in `CONTEXT.md`, call it out immediately. "Your glossary defines 'cancellation' as X, but you seem to mean Y. Which is it?"

**Sharpen fuzzy language.** When the user uses vague or overloaded terms, propose a precise canonical term. "You're saying 'account': do you mean the Customer or the User? Those are different things."

**Discuss concrete scenarios.** When domain relationships are being discussed, stress-test them with specific scenarios that probe edge cases and force precision about boundaries between concepts.

**Cross-reference with code.** When the user states how something works, check whether the code agrees. Surface contradictions: "Your code cancels entire Orders, but you just said partial cancellation is possible. Which is right?"

**Update CONTEXT.md inline.** When a term is resolved, update `CONTEXT.md` right there. Don't batch. Use the format in [CONTEXT-FORMAT.md](./CONTEXT-FORMAT.md). `CONTEXT.md` is a glossary and nothing else: no implementation details, no spec content, no scratch notes.

**Offer ADRs sparingly.** Only offer to create an ADR when all three are true:

1. **Hard to reverse**: the cost of changing your mind later is meaningful.
2. **Surprising without context**: a future reader will wonder "why did they do it this way?"
3. **The result of a real trade-off**: there were genuine alternatives and one was picked for specific reasons.

If any is missing, skip the ADR. Use the format in [ADR-FORMAT.md](./ADR-FORMAT.md). Number ADRs sequentially (`0001-`, `0002-`, ...).

---

## Finishing

Summarise: the numbered list of resolved decisions, the glossary terms added or changed, and the ADRs written. Suggest the `to-spec` skill (spec issue) or `to-tickets` skill (tracer-bullet tickets) as the next step.
