---
name: grill-me
description: "Relentless interview to sharpen a plan, design, feature idea, or decision before any code is written. Use when the user says 'grill me', 'stress-test this', 'poke holes in this plan', 'help me scope this', or wants to think a change through properly. Works for small tasks and big features, greenfield or existing code. Produces a resolved design tree, not code."
---

# Grill Me

Interview the user relentlessly until you reach a shared understanding. Map this as a **design tree**: every decision branches into the decisions that hang off it.

## How to run the interview

Work the tree in **rounds**. The **frontier** is every decision whose prerequisites are already settled: the questions you can ask _now_ without guessing at answers you haven't heard yet. Ask the whole frontier in one round: number each question and give your recommended answer. Then wait for the user's answers before the next round.

Format a round like so:

```
❓ **Q1** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>

➡️ <your recommended answer>

---

❓ **Q2** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>

➡️ <your recommended answer>
```

Each round the user answers reshapes the tree: settled decisions push the frontier outward and unblock questions that depended on them. Recompute the frontier and ask the next round. A question whose answer depends on another question still open in this round belongs to a _later_ round, not this one.

## Facts vs decisions

Finding _facts_ is your job, never the user's. When a frontier question needs a fact from the environment (the codebase, config, git history, docs), go and look it up yourself with the tools you have (search, read files, run commands) before asking. Don't ask the user for anything you could look up. The _decisions_ are the user's: put each to them and wait.

Before the first round in an existing repo, read `CONTEXT.md` and any ADRs under `docs/adr/` that touch the area (see `docs/agents/domain.md`). Use the project's vocabulary in your questions.

## Scope discipline

Always include, somewhere in the tree, the questions that guard against over-engineering:

- What is the **smallest change** that satisfies the need? Could an existing mechanism be reused instead of a new one?
- What are we **deliberately not building** in this iteration?
- Which decision could be **deferred** until we learn more, at low cost?

Record the answers; they become the "Out of scope" section of the spec later.

## Finishing

The session is done when the frontier is empty: every branch of the design tree visited, nothing left silently assumed. Summarise the resolved tree in a short numbered list of decisions. Do not act on it until the user confirms you have reached a shared understanding.

Natural next steps the user may ask for: the `to-spec` skill (turn this conversation into a spec issue) or the `to-tickets` skill (break it into tracer-bullet tickets).
