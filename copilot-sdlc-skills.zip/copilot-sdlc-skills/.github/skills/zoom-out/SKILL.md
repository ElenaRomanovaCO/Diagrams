---
name: zoom-out
description: "Gather the surrounding system context before editing unfamiliar code in an existing project: who calls this, what it depends on, which domain terms and ADRs apply, how it is tested and deployed. Use before any change to code you have not worked in during this session, when the user says 'zoom out', 'what does this touch', 'give me context on', or when a task's blast radius is unclear. Produces a short context brief, not code."
---

# Zoom Out

Before changing code you don't already understand, build a brief of the system around it. This prevents the two classic brownfield failures: fixing the symptom in the wrong layer, and breaking a caller you didn't know existed.

## Process

### 1. Anchor

Identify the anchor: the file(s), function(s), route(s), or module the task touches. If the user gave only a feature name, search the codebase for it (names, routes, labels, domain terms) and confirm the anchor with the user if ambiguous.

### 2. Read the project's own documentation first

In this order, reading only what exists (proceed silently past missing files):

1. `CONTEXT.md` (or `CONTEXT-MAP.md` → the relevant `CONTEXT.md`): the vocabulary.
2. `docs/adr/`: any ADR whose title touches the anchor's area.
3. `docs/codebase/` (from the acquire-codebase-knowledge skill): `ARCHITECTURE.md`, `CONVENTIONS.md`, `TESTING.md`, `CONCERNS.md`.
4. `.github/copilot-instructions.md`, `AGENTS.md`, `README.md`, `CONTRIBUTING.md`.

### 3. Trace the graph

Use search and file reads (never guesses) to answer:

- **Inbound**: who imports / calls / renders / routes to the anchor? List each caller with its path.
- **Outbound**: what does the anchor depend on: modules, services, DB tables, external APIs, env vars, feature flags?
- **Data**: what shapes flow in and out (types, schemas, DTOs)? Where are they defined?
- **Tests**: which tests cover the anchor and its callers? How are they run?
- **Delivery**: how does this code reach production (build, CI workflow, deploy target)? Any migrations involved?
- **History**: `git log --oneline -15 -- <anchor path>` to see recent intent, plus any referenced issue numbers.

Stop expanding when you reach module boundaries that the task will clearly not cross. Zooming out is bounded, not exhaustive.

### 4. Write the brief

Present a **context brief** in this shape, under 300 words:

```
## Context brief: <anchor>

**Purpose:** one sentence, in the glossary's vocabulary.
**Callers (inbound):** ...
**Dependencies (outbound):** ...
**Data shapes:** ...
**Tests:** ... (command to run them)
**Delivery:** ...
**Relevant decisions:** ADR-000N ..., conventions ...
**Risks / blast radius:** what could break, what needs a migration or a flag.
**Open questions for the user:** numbered, only genuine decisions, no facts you could look up.
```

Then wait. Do not start implementing until the user has seen the brief, unless they explicitly asked you to zoom out and then proceed.

## Pairing

Zoom-out feeds the other skills: run it before grill-me on an existing project, before writing-plans, and before to-tickets so ticket boundaries respect the real module boundaries.
