---
name: web-design-guidelines
description: "Review UI code (React/Next.js components, pages, CSS) against 100+ Web Interface Guidelines covering accessibility, responsive layout, forms, focus, motion, performance and UX. Use when asked to 'review my UI', 'check accessibility', 'audit design', 'review UX', 'check this component against best practices', or before opening a PR that touches frontend code."
metadata:
  author: vercel
  version: "1.0.0"
  argument-hint: <file-or-pattern>
---

# Web Interface Guidelines

Review files for compliance with the Web Interface Guidelines.

## How it works

1. Read the rules in [GUIDELINES.md](./GUIDELINES.md) (vendored copy of Vercel's web-interface-guidelines). If you have web access and the user wants the very latest rules, you may refresh from `https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md`, otherwise use the local copy.
2. Read the specified files (or ask the user for files / a glob pattern).
3. Check against every rule.
4. Output findings in the terse `file:line` format defined at the end of GUIDELINES.md, grouped by severity, with a one-line fix for each.

If no files are specified, ask which files to review. For a whole PR, review every changed file under the frontend folders.
