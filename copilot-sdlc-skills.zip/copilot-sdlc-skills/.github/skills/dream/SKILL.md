---
name: dream
description: "Memory consolidation for the repo's agent knowledge, modelled on Claude's dreaming: reviews docs/agents/LESSONS.md and recent git history, finds lessons that recur, resolves contradictions, promotes repeated lessons into copilot-instructions.md, CODING_STANDARDS.md, CONTEXT.md or ADRs, prunes one-offs, and keeps LESSONS.md short. Use when the user says 'dream', 'consolidate lessons', 'clean up agent memory', weekly, or whenever LESSONS.md grows past ~80 lines. Never run it in the middle of a feature."
---

# Dream

Sleep for the repo's agent memory. Retro writes lessons as they happen; dream is where they get sorted, merged and promoted so the agent stops repeating mistakes without the instruction files growing without bound.

Runs in four phases. Do not skip phases; do not touch application code.

## Phase 1: Orient

Inventory what exists, reading only what is present:

- `docs/agents/LESSONS.md` (the input; if missing, say so and stop)
- `.github/copilot-instructions.md`, `AGENTS.md`
- `CODING_STANDARDS.md`, `CONTRIBUTING.md`
- `CONTEXT.md`, `docs/adr/`
- `docs/codebase/` (from acquire-codebase-knowledge)
- The date of the last dream: the `Last consolidated:` line at the top of LESSONS.md, if any.

Report counts: lessons since last dream, by category.

## Phase 2: Gather signal

Beyond LESSONS.md, look for evidence the lessons missed:

- `git log --since=<last dream> --oneline` and the PRs it references: recurring "fix", "revert", "oops" commits point at a missing check or convention.
- Review comments on merged PRs since the last dream (`gh pr list --state merged --search "merged:>=<date>"` then `gh pr view <n> --comments`) if `gh` is available: repeated reviewer remarks are lessons nobody wrote down.
- Contradictions between what LESSONS.md says and what the instruction files or the code currently do.

Add anything found to your working list, marked `[from git]` or `[from reviews]`.

## Phase 3: Consolidate

For each lesson in the working list, decide one of:

- **Promote**: it recurred (2+ sightings, or 1 sighting plus corroboration from git/reviews), it is still true, and it has a durable home:
  - behavioural rule for every session → `.github/copilot-instructions.md`, under "Working rules", one line, no rationale longer than a clause
  - code rule a reviewer should enforce → `CODING_STANDARDS.md`
  - vocabulary → `CONTEXT.md` (glossary format; no implementation detail)
  - hard-to-reverse decision with real trade-offs → new ADR in `docs/adr/`
  - something a tool can enforce → open an issue "Add check: ..." via `docs/agents/issue-tracker.md`, then treat the lesson as promoted
- **Merge**: same lesson stated twice → keep the clearest phrasing, keep the earliest date, note the count.
- **Keep**: seen once, plausible to recur, not yet promotable → stays in LESSONS.md.
- **Drop**: one-off, expired (the code it described is gone), superseded, or contradicted by a newer lesson. When two lessons conflict, the newer one wins unless the code says otherwise; check the code.

Rules for promotion targets:

- Instruction files are expensive: every line is read on every turn. Promote only rules that change behaviour; prefer a pointer to a doc over a paragraph. If `copilot-instructions.md` exceeds ~150 lines, move detail out into `docs/agents/*.md` and leave a one-line pointer.
- Never write a rule that tells the agent to skip verification, suppress disagreement, or bypass review.
- Convert relative time ("last week") into absolute dates.

## Phase 4: Prune and index

Rewrite `docs/agents/LESSONS.md`:

```markdown
# Lessons learned

Append-only log written by the `retro` skill; consolidated by the `dream` skill.
Last consolidated: YYYY-MM-DD (N lessons promoted, M merged, K dropped)

## Promoted (pointer only)
- <one line per promoted lesson> → <file it now lives in>

## Active lessons
- YYYY-MM-DD [category] ... (×2)
```

Target under 60 lines. Keep the "Promoted" section short: it exists so the next dream does not re-promote the same thing; trim entries older than ~90 days.

## Report

Show the user, before writing anything: the promotions with their exact target lines, merges, drops with a one-word reason each. Wait for approval, then apply all edits, then show the final diff summary (files changed, line counts before/after). Do not commit; the user decides.

## Scheduling

Copilot has no hooks, so dream does not auto-run. Options: run it manually each Monday; or create a recurring GitHub issue "Weekly dream" labelled `ready-for-agent` assigned to the Copilot coding agent with the body "Run the dream skill and open a PR with the consolidation."
